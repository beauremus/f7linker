# F7 Linker Web Extension

This extension is intended to add an F7 like feature the FNAL AD ELog.

It uses web accessible ACL:

`http://www-ad.fnal.gov/cgi-bin/acl.pl?acl=~kissel/acl/mshow.acl+F:LNM1US+/device_index`

to link to the appropriate help page:

`https://www-bd.fnal.gov/cgi-bin/devices.pl/157689.html`

## Build

I'm using the [web-ext](https://www.npmjs.com/package/web-ext) package to test and build this extenion.
